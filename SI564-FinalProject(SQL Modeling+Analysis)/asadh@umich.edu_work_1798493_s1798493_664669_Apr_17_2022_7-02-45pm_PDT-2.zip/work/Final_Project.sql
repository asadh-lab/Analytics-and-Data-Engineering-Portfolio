-- MySQL dump 10.13  Distrib 8.0.20, for Linux (x86_64)
--
-- Host: 34.134.16.183    Database: Final_Project
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Company`
--

DROP TABLE IF EXISTS `Company`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Company` (
  `CompanyID` int NOT NULL AUTO_INCREMENT,
  `CompanyName` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`CompanyID`),
  UNIQUE KEY `Company_CompanyID_uindex` (`CompanyID`),
  UNIQUE KEY `Company_CompanyName_uindex` (`CompanyName`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Company`
--

LOCK TABLES `Company` WRITE;
/*!40000 ALTER TABLE `Company` DISABLE KEYS */;
INSERT INTO `Company` VALUES (5,'DarkHorse'),(3,'DC'),(8,'Icon Comics'),(4,'Image'),(1,'Marvel'),(2,'Original');
/*!40000 ALTER TABLE `Company` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Genre`
--

DROP TABLE IF EXISTS `Genre`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Genre` (
  `GenreID` int NOT NULL AUTO_INCREMENT,
  `Genre` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`GenreID`),
  UNIQUE KEY `Genre_GenreID_uindex` (`GenreID`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Genre`
--

LOCK TABLES `Genre` WRITE;
/*!40000 ALTER TABLE `Genre` DISABLE KEYS */;
INSERT INTO `Genre` VALUES (1,'Action'),(2,'Drama'),(3,'Crime'),(4,'Western'),(5,'Detective'),(7,'Horror'),(8,'HistoricalFiction'),(9,'Fanatasy'),(10,'Comedy'),(11,'Animation'),(12,'FoundFootage'),(16,'Adventure'),(24,'Noir'),(25,'Sci-Fi'),(26,'Thriller'),(27,'Mystery'),(28,'Spoof'),(29,'Family'),(31,'Monster'),(32,'RomCom'),(33,'Heist'),(34,'SpaceOpera'),(35,'SocialCommentary'),(36,'Espionage');
/*!40000 ALTER TABLE `Genre` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MovieToGenre`
--

DROP TABLE IF EXISTS `MovieToGenre`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MovieToGenre` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `MovieID` int DEFAULT NULL,
  `GenreID` int DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `MovieToGenre_ID_uindex` (`ID`),
  KEY `MovieToGenre_Movies_MovieID_fk` (`MovieID`),
  KEY `MovieToGenre_Genre_GenreID_fk` (`GenreID`),
  CONSTRAINT `MovieToGenre_Genre_GenreID_fk` FOREIGN KEY (`GenreID`) REFERENCES `Genre` (`GenreID`),
  CONSTRAINT `MovieToGenre_Movies_MovieID_fk` FOREIGN KEY (`MovieID`) REFERENCES `Movies` (`MovieID`)
) ENGINE=InnoDB AUTO_INCREMENT=286 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MovieToGenre`
--

LOCK TABLES `MovieToGenre` WRITE;
/*!40000 ALTER TABLE `MovieToGenre` DISABLE KEYS */;
INSERT INTO `MovieToGenre` VALUES (21,1,1),(22,1,2),(23,1,16),(24,5,1),(25,5,16),(26,5,25),(27,6,35),(28,6,26),(29,6,1),(30,4,9),(31,4,34),(32,4,10),(34,3,16),(35,3,25),(36,3,1),(37,2,2),(38,2,1),(39,2,25),(40,2,10),(41,2,34),(42,7,25),(43,7,34),(44,7,1),(45,8,1),(46,8,16),(47,8,25),(48,9,1),(49,9,16),(50,9,25),(51,10,8),(52,10,1),(53,10,25),(54,11,25),(55,11,34),(56,11,10),(57,12,9),(58,12,1),(59,12,16),(60,13,25),(61,13,35),(62,13,1),(63,14,1),(64,14,16),(65,14,26),(66,15,1),(67,15,16),(68,15,25),(69,16,7),(70,16,25),(71,16,26),(72,17,9),(73,17,2),(74,17,1),(75,18,33),(76,18,10),(77,18,1),(78,18,16),(79,18,29),(80,19,1),(81,19,26),(82,19,35),(83,19,36),(84,14,36),(85,20,25),(86,20,1),(87,20,26),(88,21,9),(89,21,1),(90,21,16),(91,22,1),(92,22,25),(93,22,16),(94,23,1),(95,23,16),(96,23,25),(97,24,33),(98,24,32),(99,24,10),(100,24,29),(101,25,31),(102,25,26),(103,25,25),(104,25,1),(105,26,3),(106,26,1),(107,26,24),(108,26,2),(109,27,9),(110,27,2),(111,27,16),(112,28,3),(113,28,26),(114,28,35),(115,29,26),(116,29,3),(117,29,5),(118,29,36),(119,29,24),(120,30,24),(121,30,35),(122,30,1),(123,31,3),(124,31,9),(125,31,16),(126,32,3),(127,32,2),(128,32,5),(129,32,24),(130,32,26),(131,32,35),(132,33,1),(133,33,16),(134,33,9),(135,34,25),(136,34,1),(137,34,26),(138,35,9),(139,35,29),(140,35,2),(141,36,26),(142,36,2),(143,36,1),(144,37,3),(145,37,24),(146,37,5),(147,38,1),(148,38,35),(149,38,16),(150,38,26),(151,39,5),(152,39,3),(153,39,24),(154,40,28),(155,40,10),(156,40,1),(157,41,9),(158,41,16),(159,41,1),(160,42,3),(161,42,1),(162,42,24),(163,43,34),(164,43,25),(165,43,16),(166,44,24),(167,44,3),(168,44,5),(169,45,25),(170,45,16),(171,45,1),(172,46,3),(173,46,24),(174,47,36),(175,47,26),(176,47,1),(177,48,10),(178,48,1),(179,48,16),(180,49,1),(181,49,10),(182,49,3),(183,50,26),(184,50,10),(185,50,1),(186,50,16),(187,51,26),(188,51,10),(189,51,1),(190,51,16),(191,52,7),(192,52,9),(193,52,2),(194,52,1),(195,52,10),(196,53,10),(197,53,1),(198,53,25),(199,54,28),(200,54,10),(201,54,1),(202,55,28),(203,55,10),(204,55,1),(205,56,9),(206,56,1),(207,56,16),(208,57,1),(209,57,2),(210,57,7),(211,57,9),(212,58,3),(213,58,26),(214,59,1),(215,59,9),(216,59,8),(217,60,4),(218,60,16),(219,61,3),(220,61,1),(221,61,4),(222,62,5),(223,62,27),(224,62,24),(225,63,1),(226,63,10),(227,63,3),(228,64,1),(229,64,10),(230,64,9),(231,65,9),(232,65,31),(233,65,1),(234,66,7),(235,66,25),(236,66,1),(237,67,3),(238,67,26),(239,67,24),(240,68,8),(241,68,1),(242,68,2),(243,69,9),(244,69,16),(245,69,10),(246,70,10),(247,70,9),(248,70,29),(249,71,9),(250,71,7),(251,71,27),(252,72,1),(253,72,10),(254,72,7),(255,73,1),(256,73,25),(257,73,26),(258,74,2),(259,74,27),(260,74,25),(261,75,1),(262,75,16),(263,75,11),(264,76,10),(265,76,28),(266,76,2),(267,77,10),(268,77,29),(269,77,1),(270,78,12),(271,78,2),(272,78,25),(273,79,11),(274,79,1),(275,79,10),(276,80,1),(277,80,2),(278,80,9),(279,81,11),(280,81,16),(281,81,10),(282,81,29),(283,509,4),(284,509,1),(285,509,2);
/*!40000 ALTER TABLE `MovieToGenre` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Movies`
--

DROP TABLE IF EXISTS `Movies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Movies` (
  `MovieID` int NOT NULL AUTO_INCREMENT,
  `Title` varchar(255) DEFAULT NULL,
  `IMDB_Score` float DEFAULT NULL,
  `RatingID` int DEFAULT NULL,
  `CompanyID` int DEFAULT NULL,
  `USA_Gross_M` float DEFAULT NULL,
  `RuntimeM` float DEFAULT NULL,
  `YearID` int DEFAULT NULL,
  PRIMARY KEY (`MovieID`),
  UNIQUE KEY `Movies_MovieID_uindex` (`MovieID`),
  KEY `Movies_Rating_RatingID_fk` (`RatingID`),
  KEY `Movies_Company_CompanyID_fk` (`CompanyID`),
  KEY `Movies_Year_YearID_fk` (`YearID`),
  CONSTRAINT `Movies_Company_CompanyID_fk` FOREIGN KEY (`CompanyID`) REFERENCES `Company` (`CompanyID`),
  CONSTRAINT `Movies_Rating_RatingID_fk` FOREIGN KEY (`RatingID`) REFERENCES `Rating` (`RatingID`),
  CONSTRAINT `Movies_Year_YearID_fk` FOREIGN KEY (`YearID`) REFERENCES `Year` (`YearID`)
) ENGINE=InnoDB AUTO_INCREMENT=513 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Movies`
--

LOCK TABLES `Movies` WRITE;
/*!40000 ALTER TABLE `Movies` DISABLE KEYS */;
INSERT INTO `Movies` VALUES (1,'Avengers: Endgame',8.4,1,1,858.37,181,1),(2,'Guardians of the Galaxy',8,1,1,333.18,121,2),(3,'Spider-Man: Far from Home',7.5,1,1,390.53,129,1),(4,'Thor: Ragnarok',7.9,1,1,315.06,130,3),(5,'Avengers: Infinity War',8.4,1,1,678.82,149,4),(6,'Black Panther',7.3,1,1,700.06,134,4),(7,'Captain Marvel',6.9,1,1,426.83,123,1),(8,'Spider-Man: Homecoming',7.4,1,1,334.2,133,3),(9,'Avengers: Age of Ultron',7.3,1,1,459.01,141,5),(10,'Captain America: The First Avenger',6.9,1,1,176.65,124,6),(11,'Guardians of the Galaxy Vol. 2',7.6,1,1,389.81,136,3),(12,'Thor',7,1,1,181.03,115,6),(13,'Iron Man',7.9,1,1,318.41,126,7),(14,'Captain America: Civil War',7.8,1,1,408.08,147,8),(15,'The Avengers',8,1,1,623.28,143,9),(16,'Brightburn',6.1,2,2,17.3,90,1),(17,'Doctor Strange',7.5,1,1,232.64,115,8),(18,'Ant-Man',7.3,1,1,180.2,117,5),(19,'Captain America: The Winter Soldier',7.7,1,1,259.77,136,2),(20,'Iron Man 3',7.1,1,1,409.01,130,10),(21,'Thor: The Dark World',6.9,1,1,206.36,112,10),(22,'Iron Man 2',7,1,1,312.43,124,11),(23,'Spider-Man 3',6.2,1,1,336.53,139,12),(24,'Ant-Man and the Wasp',7,1,1,216.65,118,4),(25,'The Incredible Hulk',6.7,1,1,134.52,112,7),(26,'Punisher: War Zone',5.9,2,1,7.95,103,7),(27,'Wonder Woman 1984',5.4,1,3,46.37,151,13),(28,'Joker',8.4,2,3,335.45,122,1),(29,'The Dark Knight',9,1,3,534.86,152,7),(30,'Watchmen',7.6,2,3,107.51,162,14),(31,'Suicide Squad',5.9,1,3,325.1,123,8),(32,'The Dark Knight Rises',8.4,1,3,448.14,164,9),(33,'Aquaman',6.9,1,3,335.06,143,4),(34,'Man of Steel',7,1,3,291.05,143,10),(35,'Shazam!',7,1,3,140.37,132,1),(36,'Batman v Superman: Dawn of Justice',6.4,1,3,330.36,152,8),(37,'Batman Begins',8.2,1,3,206.85,140,15),(38,'V for Vendetta',8.1,2,3,70.51,132,15),(39,'Batman',7.5,1,3,251.19,126,16),(40,'Batman & Robin',3.8,1,3,107.33,125,17),(41,'Constantine',7,2,3,75.98,121,15),(42,'Batman Forever',5.4,1,3,184.03,121,18),(43,'Green Lantern',5.5,1,3,116.6,114,6),(44,'Batman Returns',7,1,3,162.83,126,19),(45,'Superman Returns',6,1,3,200.08,154,20),(46,'Catwoman',3.4,1,3,40.2,104,21),(47,'Black Widow',6.7,1,1,183.65,133,13),(48,'The Suicide Squad',7.2,2,3,55.82,132,24),(49,'Blankman',5,1,2,7.89,92,23),(50,'Red',7,2,3,90.38,111,11),(51,'Red 2',6.6,2,3,53.26,116,10),(52,'The Crow',7.5,2,4,50.69,102,23),(53,'Tank Girl',5.3,2,4,4.06,104,18),(54,'Kick-Ass',7.6,2,4,48.07,117,11),(55,'Kick-Ass 2',6.5,2,4,28.8,103,10),(56,'I Kill Giants',6.1,3,4,0.34,116,3),(57,'Spawn',5.2,1,4,54.87,96,17),(58,'The Last Days of American Crime',3.7,4,4,0,148,13),(59,'The Old Guard',6.6,2,4,0,125,13),(60,'Jonah Hex',4.7,1,3,10.55,81,11),(61,'Birds of Prey',6,2,3,84.17,109,1),(62,'The Batman',8.3,1,3,359.05,176,24),(63,'The Mask',6.9,1,5,119.94,101,23),(64,'Mystery Men',6.1,1,5,29.76,121,25),(65,'Hellboy',6.9,1,5,59.62,122,21),(66,'Alien vs. Predator',5.6,1,5,80.28,101,21),(67,'Sin City',8,2,5,74.1,124,15),(68,'300',7.6,2,5,210.63,117,20),(69,'R.I.P.D',5.6,1,5,33.62,96,10),(70,'Son of the Mask',2.2,5,5,17.02,94,15),(71,'Hellboy',5.2,2,5,21.9,120,1),(72,'The Toxic Avenger Part II',5,2,2,0.79,102,16),(73,'Darkman',6.4,2,2,33.88,96,26),(74,'Unbreakable',7.3,1,2,95.01,106,27),(75,'The Incredibles',8.1,5,2,261.44,115,21),(76,'Super',6.7,2,2,0.33,96,11),(77,'Sky High',6.3,5,2,63.95,100,15),(78,'Chronicle',7,1,2,64.58,84,9),(79,'Megamind',7.3,5,2,148.42,95,11),(80,'Hancock',6.4,2,2,227.95,92,7),(81,'Incredibles 2',7.6,5,2,608.58,118,4),(509,'Logan',8.1,2,1,226.28,137,3),(510,'Kingsman:The Secret Service',7.7,2,8,128.26,129,2),(511,'Kingsman:The Golden Circle',6.7,2,8,100.23,141,3),(512,'The King\'s Man',6.3,2,8,37.18,131,22);
/*!40000 ALTER TABLE `Movies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Rating`
--

DROP TABLE IF EXISTS `Rating`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Rating` (
  `RatingID` int NOT NULL AUTO_INCREMENT,
  `Rating` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`RatingID`),
  UNIQUE KEY `Rating_RatingID_uindex` (`RatingID`),
  UNIQUE KEY `Rating_Rating_uindex` (`Rating`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Rating`
--

LOCK TABLES `Rating` WRITE;
/*!40000 ALTER TABLE `Rating` DISABLE KEYS */;
INSERT INTO `Rating` VALUES (3,'NotRated'),(5,'PG'),(1,'PG-13'),(2,'R'),(4,'TV-MA');
/*!40000 ALTER TABLE `Rating` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Year`
--

DROP TABLE IF EXISTS `Year`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Year` (
  `YearID` int NOT NULL AUTO_INCREMENT,
  `Year` year DEFAULT NULL,
  PRIMARY KEY (`YearID`),
  UNIQUE KEY `table_name_YearID_uindex` (`YearID`),
  UNIQUE KEY `table_name_Year_uindex` (`Year`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Year`
--

LOCK TABLES `Year` WRITE;
/*!40000 ALTER TABLE `Year` DISABLE KEYS */;
INSERT INTO `Year` VALUES (16,1989),(26,1990),(19,1992),(23,1994),(18,1995),(17,1997),(25,1999),(27,2000),(21,2004),(15,2005),(20,2006),(12,2007),(7,2008),(14,2009),(11,2010),(6,2011),(9,2012),(10,2013),(2,2014),(5,2015),(8,2016),(3,2017),(4,2018),(1,2019),(13,2020),(22,2021),(24,2022);
/*!40000 ALTER TABLE `Year` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-04-18  2:01:07
